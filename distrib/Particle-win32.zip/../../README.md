Particle
========

A stupid particle simulator toy thing in [Love2d](http://www.love2d.org/).

Installation
------------

Click on [releases](http://github.com/Guard13007/Particle/releases) and grab whatever is right for you.

Usage
-----

- "r" resets the simulation but is also buggy, throwing particles every which way, which is entertaining!
- "q" quits for when it starts to lag too much or you get bored of the chaos.

#!/bin/bash
love ./Particle.love

Particle
========

A stupid particle simulator toy thing in [Love2d](http://www.love2d.org/).

Installation
------------

Click on [releases](http://github.com/Guard13007/Particle/releases) and grab whatever is right for you.

System requirements: Windows XP or higher, Mac OS X 10.6+,
recommended for Ubuntu 12.04+ or similarly modern Linux distros.
(I'm just stealing this from the Love2d website, ask them what it will actually run on.)

Usage
-----

- "r" resets the simulation but is also buggy, throwing particles every which way, which is entertaining!
- "q" quits for when it starts to lag too much or you get bored of the chaos.
